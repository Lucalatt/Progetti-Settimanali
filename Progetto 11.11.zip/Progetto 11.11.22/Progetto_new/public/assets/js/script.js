var nome;
var cognome;
var addBtn;
var elencoHTML;
var errore;
var erroreElenco;
var elenco = [];
var sostituisci;

//CARICO IL DOM E FACCIO PARTIRE INIT

window.addEventListener('DOMContentLoaded', init);

//INIT PASSA I VALORI DELLE VARIABILI E RICHIAMA LE DUE FUNZIONI

function init() {
	nome = document.getElementById('nome');
	cognome = document.getElementById('cognome');
	addBtn = document.getElementById('scrivi');
	elencoHTML = document.getElementById('elenco');
	errore = document.getElementById('errore');
	erroreElenco = document.getElementById('erroreElenco');
	printData();
	eventHandler();
}

//STAMPA LA LISTA RECUPERANDO IL JSON

function printData() {
	fetch('http://localhost:3000/elenco')
		.then((response) => {
			return response.json();
		})
		.then((data) => {
			elenco = data;
			if (elenco.length > 0) {
				errore.innerHTML = '';
				elencoHTML.innerHTML = '';
				elenco.map(function (element) {
					elencoHTML.innerHTML += `<li><button type="button" class="btn btn-danger me-2" onClick="elimina(${element.id})"><i class="bi bi-trash"></i></button><button type="button" class="btn btn-warning me-2" onClick="modifica(${element.id})"><i class="bi bi-pencil-square"></i></button>
                    ${element.nome} ${element.cognome}</li>`;
				});
			} else {
				erroreElenco.innerHTML = 'Nessun elemento presente in elenco';
			}
		});
}

function eventHandler() {
	addBtn.addEventListener('click', function () {
		if (sostituisci) {
			overwrite(sostituisci)
		} else {
		controlla();
		}
	});
}

//VERIFICA I VALORI INSERITI NEL FORM

function controlla() {
	if (nome.value != '' && cognome.value != '') {
		var data = {
			nome: nome.value,
			cognome: cognome.value,
		};
		addData(data);
	} else {
		errore.innerHTML = 'Compilare correttamente i campi!';
		return;
	}
}

//AGGIUNGE UN VALORE ALL'ELENCO

async function addData(data) {
	let response = await fetch('http://localhost:3000/elenco', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json;charset=utf-8',
		},
		body: JSON.stringify(data),
	});
	clearForm();
}

//ELIMINA UN VALORE DALL'ELENCO

async function elimina(i) {
	richiesta = window.confirm('Sei sicuro di voler cancellare?');
	if (richiesta) {
		return fetch('http://localhost:3000/elenco/' + i, {
			method: 'DELETE'
		});
	}
}

function clearForm() {
	nome.value = '';
	cognome.value = '';
}

// MODIFICA UN NOME DALL'ELENCO

function modifica(i) {
	fetch(`http://localhost:3000/elenco/${i}`)
	.then((response) => {
		return response.json();
	})
	.then((data) => {
		nome.value = data.nome;
		cognome.value = data.cognome;
	});
	
	return sostituisci = i;
}

function overwrite(i) {
	if (nome.value && cognome.value) {
	fetch(`http://localhost:3000/elenco/${i}`, {
		method: 'PUT',
		headers: {
			'Content-Type': 'application/json;charset=utf-8',
		},
		body: JSON.stringify({
			"nome": nome.value,
			"cognome": cognome.value
		}),
	})


	
	clearForm();
	} else {
		errore.innerHTML = 'Compilare correttamente i campi!';
		return;
	}
}

