export interface Movie {
    id: number,
    poster_path: string,
    title: string,
    like: boolean,
    userId: number,
    vote_average: number,
    overview: string
}
