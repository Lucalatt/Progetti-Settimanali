export interface Favorite {
    movieId: number,
      userId: number,
      id: number,
      like: boolean,
      poster_path: string,
      title: string,
      vote_average: number,
      overview: string
    }
