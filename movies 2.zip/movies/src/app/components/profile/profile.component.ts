import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { FavoriteUser } from 'src/app/models/favorite-user.model';
import { FavoritesService } from 'src/app/services/favorite.service';
import { Favorite } from 'src/app/models/favorite.model';

@Component({
  selector: 'app-profile',
  template: `
   <app-navbar></app-navbar>


  <div class="container-fluid text-blue mb-5">
    <div class="container-fluid d-flex flex-column align-items-center mb-5">

      <div class="mb-3 form-floating form-group">
      <input name="name" type="name" class="form-control" id="email" placeholder="name" disabled>
      <label for="email"><i class="bi bi-person"></i> {{userdata.user.name}}</label>
    </div>
  <div class="mb-3 form-floating form-group">
    <input name="email" type="email" class="form-control" id="email" placeholder="name@example.com" disabled>
    <label for="email"><i class="bi bi-envelope"></i> {{userdata.user.email}}</label>
  </div>
  </div>



  `,
  styles: [
  ]
})
export class ProfileComponent implements OnInit {

  constructor(private http: HttpClient, private fvrSrv: FavoritesService) { }

  userdata: any = [];
  favoriteUser: FavoriteUser[] | undefined
  sub: Subscription | undefined
  favorites: Favorite[] | undefined


  ngOnInit(): void {
    this.getUser();
    this.getFavoriteUsers()
  }
  pageData = false;

  getUser() {
    let userLogged: any = localStorage.getItem('user');
    this.userdata = JSON.parse(userLogged);
  }

  getFavoriteUsers() {
    this.sub = this.fvrSrv.getFavoritesUser(this.userdata.user.id).subscribe((ris) => {
      this.favoriteUser = ris;
      this.pageData = true;
    });
  }

  dislike(idMov: number) {
    //ottengo l'array dei favoriti
    this.sub = this.fvrSrv.getFavorites().subscribe((ris) => {
      this.favorites = ris;

      //controllo se l'elemento esiste
      if (ris.find(item => item.movieId === idMov && item.userId === this.userdata.user.id)) {


        //se esiste, mi controlli se i dati sono uguali e mi restituisci l'id del dato da eliminare
        const item = ris.find(item => item.movieId === idMov && item.userId === this.userdata.user.id);
        const id = item ? item.id : undefined;



        //Elimina quel dato dal json favoriti
        this.sub = this.fvrSrv.deleteFavorites(id!).subscribe((ris) => {
          console.log('Elemento rimosso dai preferiti')
        });
        this.getFavoriteUsers();
      }
    })

  }

}
