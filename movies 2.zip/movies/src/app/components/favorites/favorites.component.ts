import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-favorites',
  template: `

    <div class="container">
      <div class="card" style="width: 18rem;">
          <img src="..." class="card-img-top" alt="...">
          <div class="card-body">
          <h5 class="card-title">Card title</h5>

    <p><i class="bi bi-heart-fill"></i></p>
  </div>
</div>
    </div>

  `,
  styles: [
  ]
})
export class FavoritesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
