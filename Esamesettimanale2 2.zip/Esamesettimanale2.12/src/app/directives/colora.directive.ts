import { Directive, ElementRef, HostListener, HostBinding, Input } from '@angular/core';

@Directive({
  selector: '[appColora]'
})
export class ColoraDirective {
  @Input() defaultColor: string = 'black';
  @Input('appColora') newCololor: string = 'yellow';

  @HostBinding ('style.background-color') color: string = 'yellow';

  constructor() { }

}
