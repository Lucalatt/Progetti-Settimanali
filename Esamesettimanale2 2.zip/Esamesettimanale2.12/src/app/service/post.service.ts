import { User } from "../models/user";
import { Post } from "../models/post";

export async function getPost(): Promise<Post[]>  {
  return await (await fetch('http://localhost:3000/list')).json();
}

export async function getUser(): Promise<User[]>  {
  return await (await fetch('http://localhost:3000/users')).json();
}

