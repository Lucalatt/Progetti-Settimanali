import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Route, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ActivePostComponent } from './components/activepost/activepost.component';
import { InactivePostComponent } from './components/inactivepost/inactivepost.component';
import { CardComponent } from './components/card/card.component';
import { UsersComponent } from './components/users/users.component';
import { ColoraDirective } from './directives/colora.directive';
import { MaiuscoloPipe } from './pipes/maiuscolo.pipe';
import { FormsModule } from '@angular/forms';
import { DettagliopostComponent } from './components/dettagliopost/dettagliopost.component';
import { UserdetailComponent } from './components/userdetail/userdetail.component';
import { CardDetailComponent } from './components/card-detail/card-detail.component';
import { NewPostComponent } from './components/new-post/new-post.component';

const routes: Route[] = [
  {
    path: "",
    component: HomeComponent,
    children: [
      {
        path: "newPost",
        component: NewPostComponent
    }
  ]
  },
  {
    path: "activePost",
    component: ActivePostComponent,
  },
  {
    path: 'activePost/:id',
    component: DettagliopostComponent
  },
  {
    path: "inactivePost",
    component: InactivePostComponent
  },
  {
    path: "inactivePost/:id",
    component: DettagliopostComponent
  },
  {
    path: "users",
    component: UsersComponent,
    children: [
      {
        path: ":id",
        component: UserdetailComponent
      }
    ]
  }
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarComponent,
    ActivePostComponent,
    InactivePostComponent,
    CardComponent,
    UsersComponent,
    ColoraDirective,
    MaiuscoloPipe,
    DettagliopostComponent,
    UserdetailComponent,
    CardDetailComponent,
    NewPostComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
