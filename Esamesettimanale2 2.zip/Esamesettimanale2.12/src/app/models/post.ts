export interface Post {
  body: string,
  title: string,
  active: boolean,
  type: string,
  author: string,
  id: number
}
