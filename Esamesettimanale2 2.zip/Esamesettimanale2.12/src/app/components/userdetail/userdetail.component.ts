import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { User } from 'src/app/models/user';
import { getUser } from 'src/app/service/post.service';

@Component({
  selector: 'app-userdetail',
  templateUrl: './userdetail.component.html',
  styleUrls: ['./userdetail.component.scss']
})
export class UserdetailComponent implements OnInit {

  u: User | undefined

  constructor(private ar: ActivatedRoute) { }

  ngOnInit(): void {
    let x = this.ar.snapshot.params["id"];

    getUser().then((users: User[]) => {
      this.u = users.find((element) => {
        if(x == element.id) {
          return true;
        } else {
          return false;
        }
      })
    })
  }

}
