import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-post',
  templateUrl: './new-post.component.html',
  styleUrls: ['./new-post.component.scss']
})
export class NewPostComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  register(title: string, body: string, type: string, author: string) {
    if (title != "" && body != ""  && type !=  "" && author != "") {
      let data = {
        body: body,
        title: title,
        active: true,
        type: type,
        author: author
      }
      this.addData(data);

    }
    location.reload();
  }

  addData(data: any) {
    fetch('http://localhost:3000/list', {
      method: 'POST',
      headers: {
        'content-type': 'application/json;charset=utf-8',
      },
      body: JSON.stringify(data),
    });
  }


}
