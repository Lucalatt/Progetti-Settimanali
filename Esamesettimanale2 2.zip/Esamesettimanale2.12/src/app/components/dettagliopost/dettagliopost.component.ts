import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Post } from 'src/app/models/post';
import { getPost } from 'src/app/service/post.service';

@Component({
  selector: 'app-dettagliopost',
  templateUrl: './dettagliopost.component.html',
  styleUrls: ['./dettagliopost.component.scss']
})
export class DettagliopostComponent implements OnInit {
  p: Post | undefined

  constructor(private ar: ActivatedRoute) { }

  ngOnInit(): void {
    let x = this.ar.snapshot.params["id"];

    getPost().then((posts: Post[]) => {
      this.p = posts.find((element) => {
        if(x == element.id) {
          return true;
        } else {
          return false;
        }
      })
    })
  }

}
